
import java.io.*;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        while (true) {
            System.out.println("Welcome");

            System.out.println("1. Book a Flight");
            System.out.println("2. Check Status");
            System.out.println("3. Cancel Booking");
            System.out.println("4. Exit");

            Scanner sc = new Scanner(System.in);
            int select = sc.nextInt();

            if (select == 1) {
                booking();
            } else if (select == 2) {
                checkStatus();
            } else if (select == 3) {
                cancel();
            } else {
                break;
            }
        }
    }

    public static void booking() {
        int userCount = 0;

        String[] destinations = {"qatar", "brazil", "dubai"};
        System.out.println(Arrays.toString(destinations));

        System.out.println("Select your destination");
        Scanner sc = new Scanner(System.in);
        String d = sc.nextLine();
        String destination = d.toLowerCase();

        System.out.println("Enter Departure Date:");
        System.out.println("Format = day/month/year\nfor example: (01 / 12 / 2023)");
        String departureDate = sc.nextLine();

        System.out.println("Enter Arrival Date:");
        System.out.println("Format = day/month/year\nfor example: (01 / 12 / 2023)");
        String arrivalDate = sc.nextLine();

        boolean destinationFound = false;

        // Count the number of booked seats for the selected destination and date
        int bookedSeats = countBookedSeats(destination, departureDate);

        if (bookedSeats < 50) {
            System.out.println("Available");
            destinationFound = true;
            // Collect passenger details
            collectPassengerDetails(destination, departureDate, arrivalDate);
        } else {
            System.out.println("All seats are booked for the selected destination and date.");
        }

        if (!destinationFound) {
            System.out.println("Hum nahi jaatay idhar");
        }
    }

    private static int countBookedSeats(String destination, String departureDate) {
        int bookedSeats = 0;

        try (BufferedReader reader = new BufferedReader(new FileReader("user_info.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains("Destination: " + destination) && line.contains("Departure Date: " + departureDate)) {
                    bookedSeats++;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return bookedSeats;
    }

    private static void collectPassengerDetails(String destination, String departureDate, String arrivalDate) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of passengers: ");
        int numPassengers = sc.nextInt();

        for (int i = 0; i < numPassengers; i++) {
            System.out.println("Passenger " + (i + 1) + " Details:");

            System.out.println("Enter name: ");
            String name = sc.next();

            System.out.println("Enter email: ");
            String email = sc.next();

            System.out.println("Enter phone number: ");
            String phoneNumber = sc.next();

            System.out.println("Enter passport number: ");
            String passportNumber = sc.next();

            System.out.println("Enter gender (M/F): ");
            String gender = sc.next();

            System.out.println("Enter date of birth (day/month/year): ");
            String dob = sc.next();

            // Calculate charges based on age
            double charges = calculateCharges(dob);

            // Generate a random ticket number
            String ticketNumber = generateTicketNumber();

            // Print ticket details in a rectangular box
            // Print ticket details in a rectangular box
            printTicketDetails(destination, departureDate, arrivalDate, name, email, phoneNumber, passportNumber, gender, dob, charges, ticketNumber);

            // Save user info to a text file
            saveUserInfoToFile(name, email, phoneNumber, passportNumber, gender, dob, charges, ticketNumber);
        }
    }

    private static double calculateCharges(String dob) {
        // Extract year from the date of birth
        int birthYear = Integer.parseInt(dob.split("/")[2]);

        // Calculate age
        int age = 2024 - birthYear;

        // Calculate charges based on age
        if (age < 2) {
            return 0.4;  // 40%
        } else if (age >= 2 && age <= 10) {
            return 0.75;  // 75%
        } else {
            return 1.0;  // 100%
        }
    }

    private static String generateTicketNumber() {
        Random rand = new Random();
        int ticketNumber = rand.nextInt(1000000);
        return String.format("%06d", ticketNumber);
    }

    private static void printTicketDetails(String destination, String departureDate, String arrivalDate, String name,
                                           String email, String phoneNumber, String passportNumber, String gender,
                                           String dob, double charges, String ticketNumber) {
        // Print ticket details in a rectangular box
        System.out.println("***********************************************");
        System.out.println("               TICKET DETAILS                 ");
        System.out.println("***********************************************");
        System.out.println("Destination: " + destination);
        System.out.println("Departure Date: " + departureDate);
        System.out.println("Arrival Date: " + arrivalDate);
        System.out.println("Name: " + name);
        System.out.println("Email: " + email);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Passport Number: " + passportNumber);
        System.out.println("Gender: " + gender);
        System.out.println("Date of Birth: " + dob);
        System.out.println("Charges: " + (charges * 100) + "%");
        System.out.println("Ticket Number: " + ticketNumber);
        System.out.println("***********************************************");
    }

    private static void saveUserInfoToFile(String name, String email, String phoneNumber, String passportNumber,
                                           String gender, String dob, double charges, String ticketNumber) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("user_info.txt", true))) {
            // Save user info to a text file
            writer.write("***********************************************\n");
            writer.write("Ticket Number: " + ticketNumber + "\n");
            writer.write("Name: " + name + "\n");
            writer.write("Email: " + email + "\n");
            writer.write("Phone Number: " + phoneNumber + "\n");
            writer.write("Passport Number: " + passportNumber + "\n");
            writer.write("Gender: " + gender + "\n");
            writer.write("Date of Birth: " + dob + "\n");
            writer.write("Charges: " + (charges * 100) + "%\n");

            writer.write("***********************************************\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void checkStatus() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the ticket number to check the booking status: ");
        String ticketToCheck = sc.next();

        try (BufferedReader reader = new BufferedReader(new FileReader("user_info.txt"))) {
            String line;
            boolean bookingFound = false;

            while ((line = reader.readLine()) != null) {
                if (line.contains("Ticket Number: " + ticketToCheck)) {
                    bookingFound = true;
                    // Print details for the booking
                    for (int i = 1; i < 10; i++) {  // Print only 10 lines, excluding the asterisk line
                        System.out.println(line);
                        if (i != 9) {  // Read the next line only if it's not the last line
                            line = reader.readLine();
                        }
                    }
                    break;
                }
            }

            if (!bookingFound) {
                System.out.println("Booking with ticket number " + ticketToCheck + " not found.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void cancel() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the ticket number to cancel the booking: ");
        String ticketToCancel = sc.next();

        try (BufferedReader reader = new BufferedReader(new FileReader("user_info.txt"));
             BufferedWriter writer = new BufferedWriter(new FileWriter("user_info_temp.txt"))) {

            String line;
            boolean bookingFound = false;

            while ((line = reader.readLine()) != null) {
                if (line.contains("Ticket Number: " + ticketToCancel)) {
                    bookingFound = true;
                    // Skip lines corresponding to the booking to be canceled
                    for (int i = 0; i < 11; i++) {
                        reader.readLine();
                    }
                } else {
                    writer.write(line + "\n");  // Write non-canceled lines to the temporary file
                }
            }
            if (bookingFound) {
                System.out.println("Booking with ticket number " + ticketToCancel + " canceled successfully.");
            } else {
                System.out.println("Booking with ticket number " + ticketToCancel + " not found.");
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
// Rename temp file to the original file
        File tempFile = new File("user_info_temp.txt");
        File originalFile = new File("user_info.txt");
        if (tempFile.renameTo(originalFile)) {
            System.out.println("File updated successfully.");
        }
}



}

